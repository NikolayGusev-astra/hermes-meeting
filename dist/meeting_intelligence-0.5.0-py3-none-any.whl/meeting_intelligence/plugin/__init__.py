"""Hermes plugin registration for meeting intelligence tools."""
from __future__ import annotations

from typing import Any


def register(ctx: Any) -> None:
    """Register meeting intelligence tools with Hermes runtime."""
    ctx.register_tool(
        name="meeting_transcribe",
        description="Transcribe audio/video to timestamped transcript",
        input_schema={
            "type": "object",
            "properties": {
                "source": {"type": "string"},
                "model": {"type": "string", "default": "small"},
                "language": {"type": "string", "default": "en"},
                "device": {"type": "string", "default": "cpu", "enum": ["cpu", "cuda"]},
                "compute_type": {"type": "string", "default": "int8"},
            },
            "required": ["source"],
        },
        output_schema={
            "type": "object",
            "properties": {
                "transcript_path": {"type": "string"},
                "status": {"type": "string"},
            },
        },
        handler=lambda source, model="small", language="en", device="cpu", compute_type="int8": _run([
            "python", "scripts/meeting_cli.py", "transcribe",
            source, "--model", model, "--language", language, "--device", device, "--compute-type", compute_type,
        ]),
    )

    ctx.register_tool(
        name="meeting_translate",
        description="Translate timestamped transcript",
        input_schema={
            "type": "object",
            "properties": {
                "transcript": {"type": "string"},
                "target_lang": {"type": "string", "default": "ru"},
            },
            "required": ["transcript"],
        },
        output_schema={
            "type": "object",
            "properties": {
                "translated_path": {"type": "string"},
                "status": {"type": "string"},
            },
        },
        handler=lambda transcript, target_lang="ru": _run([
            "python", "scripts/meeting_cli.py", "translate", transcript, "--target-lang", target_lang,
        ]),
    )

    ctx.register_tool(
        name="meeting_protocol",
        description="Extract validated meeting protocol from transcript",
        input_schema={
            "type": "object",
            "properties": {
                "transcript": {"type": "string"},
                "model": {"type": "string", "default": "qwen2.5-7b-instruct"},
            },
            "required": ["transcript"],
        },
        output_schema={
            "type": "object",
            "properties": {
                "protocol_path": {"type": "string"},
                "quality": {"type": "object"},
            },
        },
        handler=lambda transcript, model="qwen2.5-7b-instruct": _run([
            "python", "scripts/meeting_cli.py", "protocol", transcript, "--model", model,
        ]),
    )

    ctx.register_tool(
        name="meeting_process",
        description="Full pipeline: audio -> transcript -> translation -> protocol",
        input_schema={
            "type": "object",
            "properties": {
                "source": {"type": "string"},
                "model": {"type": "string", "default": "small"},
                "language": {"type": "string", "default": "en"},
                "device": {"type": "string", "default": "cpu"},
                "compute_type": {"type": "string", "default": "int8"},
                "target_lang": {"type": "string", "default": "ru"},
            },
            "required": ["source"],
        },
        output_schema={
            "type": "object",
            "properties": {
                "transcript_path": {"type": "string"},
                "translated_path": {"type": "string"},
                "protocol_path": {"type": "string"},
                "quality": {"type": "object"},
            },
        },
        handler=lambda source, **kw: _run([
            "python", "scripts/meeting_cli.py", "process", source,
            "--model", kw.get("model", "small"),
            "--language", kw.get("language", "en"),
            "--device", kw.get("device", "cpu"),
            "--compute-type", kw.get("compute_type", "int8"),
            "--target-lang", kw.get("target_lang", "ru"),
        ]),
    )


def _run(argv):
    import subprocess, json
    p = subprocess.run(argv, capture_output=True, text=True)
    return {"exit_code": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
